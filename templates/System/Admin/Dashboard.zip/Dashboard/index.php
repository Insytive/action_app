<?php
    /**
     * @var \App\View\AppView $this
     * @var \App\Model\Entity\Ward[]|\Cake\Collection\CollectionInterface $wards
     */

    $this->assign('title', __('Dashboard'));
?>
