<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\User $user
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Html->link(__('Edit User'), ['action' => 'edit', $user->id], ['class' => 'side-nav-item']) ?>
            <?= $this->Form->postLink(__('Delete User'), ['action' => 'delete', $user->id], ['confirm' => __('Are you sure you want to delete # {0}?', $user->id), 'class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('List Users'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('New User'), ['action' => 'add'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column-responsive column-80">
        <div class="users view content">
            <h3><?= h($user->id) ?></h3>
            <table>
                <tr>
                    <th><?= __('Parent User') ?></th>
                    <td><?= $user->has('parent_user') ? $this->Html->link($user->parent_user->id, ['controller' => 'Users', 'action' => 'view', $user->parent_user->id]) : '' ?></td>
                </tr>
                <tr>
                    <th><?= __('First Name') ?></th>
                    <td><?= h($user->first_name) ?></td>
                </tr>
                <tr>
                    <th><?= __('Last Name') ?></th>
                    <td><?= h($user->last_name) ?></td>
                </tr>
                <tr>
                    <th><?= __('Id Number') ?></th>
                    <td><?= h($user->id_number) ?></td>
                </tr>
                <tr>
                    <th><?= __('Membership Number') ?></th>
                    <td><?= h($user->membership_number) ?></td>
                </tr>
                <tr>
                    <th><?= __('Gender') ?></th>
                    <td><?= $user->has('gender') ? $this->Html->link($user->gender->name, ['controller' => 'Genders', 'action' => 'view', $user->gender->id]) : '' ?></td>
                </tr>
                <tr>
                    <th><?= __('Email') ?></th>
                    <td><?= h($user->email) ?></td>
                </tr>
                <tr>
                    <th><?= __('Password') ?></th>
                    <td><?= h($user->password) ?></td>
                </tr>
                <tr>
                    <th><?= __('Phone') ?></th>
                    <td><?= h($user->phone) ?></td>
                </tr>
                <tr>
                    <th><?= __('Address') ?></th>
                    <td><?= h($user->address) ?></td>
                </tr>
                <tr>
                    <th><?= __('Building') ?></th>
                    <td><?= h($user->building) ?></td>
                </tr>
                <tr>
                    <th><?= __('Town') ?></th>
                    <td><?= h($user->town) ?></td>
                </tr>
                <tr>
                    <th><?= __('City') ?></th>
                    <td><?= h($user->city) ?></td>
                </tr>
                <tr>
                    <th><?= __('Voting Station') ?></th>
                    <td><?= $user->has('voting_station') ? $this->Html->link($user->voting_station->name, ['controller' => 'VotingStations', 'action' => 'view', $user->voting_station->id]) : '' ?></td>
                </tr>
                <tr>
                    <th><?= __('Branch') ?></th>
                    <td><?= $user->has('branch') ? $this->Html->link($user->branch->name, ['controller' => 'Branches', 'action' => 'view', $user->branch->id]) : '' ?></td>
                </tr>
                <tr>
                    <th><?= __('Role') ?></th>
                    <td><?= $user->has('role') ? $this->Html->link($user->role->name, ['controller' => 'Roles', 'action' => 'view', $user->role->id]) : '' ?></td>
                </tr>
                <tr>
                    <th><?= __('Token') ?></th>
                    <td><?= h($user->token) ?></td>
                </tr>
                <tr>
                    <th><?= __('Id') ?></th>
                    <td><?= $this->Number->format($user->id) ?></td>
                </tr>
                <tr>
                    <th><?= __('User Status') ?></th>
                    <td><?= $this->Number->format($user->user_status) ?></td>
                </tr>
                <tr>
                    <th><?= __('Points') ?></th>
                    <td><?= $this->Number->format($user->points) ?></td>
                </tr>
                <tr>
                    <th><?= __('Birthdate') ?></th>
                    <td><?= h($user->birthdate) ?></td>
                </tr>
                <tr>
                    <th><?= __('Created At') ?></th>
                    <td><?= h($user->created_at) ?></td>
                </tr>
                <tr>
                    <th><?= __('Updated At') ?></th>
                    <td><?= h($user->updated_at) ?></td>
                </tr>
                <tr>
                    <th><?= __('First Time Voter') ?></th>
                    <td><?= $user->first_time_voter ? __('Yes') : __('No'); ?></td>
                </tr>
            </table>
            <div class="related">
                <h4><?= __('Related Badges') ?></h4>
                <?php if (!empty($user->badges)) : ?>
                <div class="table-responsive">
                    <table>
                        <tr>
                            <th><?= __('Id') ?></th>
                            <th><?= __('Name') ?></th>
                            <th><?= __('Description') ?></th>
                            <th><?= __('Icon') ?></th>
                            <th><?= __('Level') ?></th>
                            <th><?= __('Created At') ?></th>
                            <th><?= __('Updated At') ?></th>
                            <th class="actions"><?= __('Actions') ?></th>
                        </tr>
                        <?php foreach ($user->badges as $badges) : ?>
                        <tr>
                            <td><?= h($badges->id) ?></td>
                            <td><?= h($badges->name) ?></td>
                            <td><?= h($badges->description) ?></td>
                            <td><?= h($badges->icon) ?></td>
                            <td><?= h($badges->level) ?></td>
                            <td><?= h($badges->created_at) ?></td>
                            <td><?= h($badges->updated_at) ?></td>
                            <td class="actions">
                                <?= $this->Html->link(__('View'), ['controller' => 'Badges', 'action' => 'view', $badges->id]) ?>
                                <?= $this->Html->link(__('Edit'), ['controller' => 'Badges', 'action' => 'edit', $badges->id]) ?>
                                <?= $this->Form->postLink(__('Delete'), ['controller' => 'Badges', 'action' => 'delete', $badges->id], ['confirm' => __('Are you sure you want to delete # {0}?', $badges->id)]) ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </table>
                </div>
                <?php endif; ?>
            </div>
            <div class="related">
                <h4><?= __('Related Audit Logs') ?></h4>
                <?php if (!empty($user->audit_logs)) : ?>
                <div class="table-responsive">
                    <table>
                        <tr>
                            <th><?= __('Id') ?></th>
                            <th><?= __('Description') ?></th>
                            <th><?= __('Subject Id') ?></th>
                            <th><?= __('Subject Type') ?></th>
                            <th><?= __('User Id') ?></th>
                            <th><?= __('Properties') ?></th>
                            <th><?= __('Host') ?></th>
                            <th><?= __('Created At') ?></th>
                            <th><?= __('Updated At') ?></th>
                            <th class="actions"><?= __('Actions') ?></th>
                        </tr>
                        <?php foreach ($user->audit_logs as $auditLogs) : ?>
                        <tr>
                            <td><?= h($auditLogs->id) ?></td>
                            <td><?= h($auditLogs->description) ?></td>
                            <td><?= h($auditLogs->subject_id) ?></td>
                            <td><?= h($auditLogs->subject_type) ?></td>
                            <td><?= h($auditLogs->user_id) ?></td>
                            <td><?= h($auditLogs->properties) ?></td>
                            <td><?= h($auditLogs->host) ?></td>
                            <td><?= h($auditLogs->created_at) ?></td>
                            <td><?= h($auditLogs->updated_at) ?></td>
                            <td class="actions">
                                <?= $this->Html->link(__('View'), ['controller' => 'AuditLogs', 'action' => 'view', $auditLogs->id]) ?>
                                <?= $this->Html->link(__('Edit'), ['controller' => 'AuditLogs', 'action' => 'edit', $auditLogs->id]) ?>
                                <?= $this->Form->postLink(__('Delete'), ['controller' => 'AuditLogs', 'action' => 'delete', $auditLogs->id], ['confirm' => __('Are you sure you want to delete # {0}?', $auditLogs->id)]) ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </table>
                </div>
                <?php endif; ?>
            </div>
            <div class="related">
                <h4><?= __('Related Sessions') ?></h4>
                <?php if (!empty($user->sessions)) : ?>
                <div class="table-responsive">
                    <table>
                        <tr>
                            <th><?= __('Id') ?></th>
                            <th><?= __('User Id') ?></th>
                            <th><?= __('Ip Address') ?></th>
                            <th><?= __('User Agent') ?></th>
                            <th><?= __('Payload') ?></th>
                            <th><?= __('Last Activity') ?></th>
                            <th class="actions"><?= __('Actions') ?></th>
                        </tr>
                        <?php foreach ($user->sessions as $sessions) : ?>
                        <tr>
                            <td><?= h($sessions->id) ?></td>
                            <td><?= h($sessions->user_id) ?></td>
                            <td><?= h($sessions->ip_address) ?></td>
                            <td><?= h($sessions->user_agent) ?></td>
                            <td><?= h($sessions->payload) ?></td>
                            <td><?= h($sessions->last_activity) ?></td>
                            <td class="actions">
                                <?= $this->Html->link(__('View'), ['controller' => 'Sessions', 'action' => 'view', $sessions->id]) ?>
                                <?= $this->Html->link(__('Edit'), ['controller' => 'Sessions', 'action' => 'edit', $sessions->id]) ?>
                                <?= $this->Form->postLink(__('Delete'), ['controller' => 'Sessions', 'action' => 'delete', $sessions->id], ['confirm' => __('Are you sure you want to delete # {0}?', $sessions->id)]) ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </table>
                </div>
                <?php endif; ?>
            </div>
            <div class="related">
                <h4><?= __('Related Users') ?></h4>
                <?php if (!empty($user->child_users)) : ?>
                <div class="table-responsive">
                    <table>
                        <tr>
                            <th><?= __('Id') ?></th>
                            <th><?= __('Parent Id') ?></th>
                            <th><?= __('First Name') ?></th>
                            <th><?= __('Last Name') ?></th>
                            <th><?= __('Id Number') ?></th>
                            <th><?= __('Birthdate') ?></th>
                            <th><?= __('Membership Number') ?></th>
                            <th><?= __('Gender Id') ?></th>
                            <th><?= __('Email') ?></th>
                            <th><?= __('Password') ?></th>
                            <th><?= __('Phone') ?></th>
                            <th><?= __('Address') ?></th>
                            <th><?= __('Building') ?></th>
                            <th><?= __('Town') ?></th>
                            <th><?= __('City') ?></th>
                            <th><?= __('First Time Voter') ?></th>
                            <th><?= __('User Status') ?></th>
                            <th><?= __('Voting Station Id') ?></th>
                            <th><?= __('Branch Id') ?></th>
                            <th><?= __('Role Id') ?></th>
                            <th><?= __('Token') ?></th>
                            <th><?= __('Points') ?></th>
                            <th><?= __('Created At') ?></th>
                            <th><?= __('Updated At') ?></th>
                            <th class="actions"><?= __('Actions') ?></th>
                        </tr>
                        <?php foreach ($user->child_users as $childUsers) : ?>
                        <tr>
                            <td><?= h($childUsers->id) ?></td>
                            <td><?= h($childUsers->parent_id) ?></td>
                            <td><?= h($childUsers->first_name) ?></td>
                            <td><?= h($childUsers->last_name) ?></td>
                            <td><?= h($childUsers->id_number) ?></td>
                            <td><?= h($childUsers->birthdate) ?></td>
                            <td><?= h($childUsers->membership_number) ?></td>
                            <td><?= h($childUsers->gender_id) ?></td>
                            <td><?= h($childUsers->email) ?></td>
                            <td><?= h($childUsers->password) ?></td>
                            <td><?= h($childUsers->phone) ?></td>
                            <td><?= h($childUsers->address) ?></td>
                            <td><?= h($childUsers->building) ?></td>
                            <td><?= h($childUsers->town) ?></td>
                            <td><?= h($childUsers->city) ?></td>
                            <td><?= h($childUsers->first_time_voter) ?></td>
                            <td><?= h($childUsers->user_status) ?></td>
                            <td><?= h($childUsers->voting_station_id) ?></td>
                            <td><?= h($childUsers->branch_id) ?></td>
                            <td><?= h($childUsers->role_id) ?></td>
                            <td><?= h($childUsers->token) ?></td>
                            <td><?= h($childUsers->points) ?></td>
                            <td><?= h($childUsers->created_at) ?></td>
                            <td><?= h($childUsers->updated_at) ?></td>
                            <td class="actions">
                                <?= $this->Html->link(__('View'), ['controller' => 'Users', 'action' => 'view', $childUsers->id]) ?>
                                <?= $this->Html->link(__('Edit'), ['controller' => 'Users', 'action' => 'edit', $childUsers->id]) ?>
                                <?= $this->Form->postLink(__('Delete'), ['controller' => 'Users', 'action' => 'delete', $childUsers->id], ['confirm' => __('Are you sure you want to delete # {0}?', $childUsers->id)]) ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </table>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
